
import java.util.*;

public class CollectionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(problemOne("India","America","Russia","Japan","Africa"));
		System.out.println(problemTwo());
		System.out.println(problemThree());

	}
	public static List<String> problemOne(String c1,String c2,String c3,String c4,String c5 )
	{
		List<String> lst=new ArrayList<String>();
		lst.add(c1);
		lst.add(c2);
		lst.add(c3);
		lst.add(c4);
		lst.add(c5);
		return lst;
		
		
		
	}
	public static List<Integer> problemTwo()
	{
		List<Integer> lst=new ArrayList<Integer>();
		for(int i=0;i<=10;i++)
		{
			lst.add(i);
		}
		return lst;
	}
	public static List<Integer> problemThree()
	{
		List<Integer> lst2 = new ArrayList<Integer>(CollectionDemo.problemTwo());
		//lst2.add(CollectionDemo.problemThree());
		for(int i=11;i<=15;i++)
		{
			lst2.add(i);
		}
		return lst2;
	}
	

}
