package HierarchialInheritanceExample;

 class Subtraction extends Addition {
	public    static void Subtract(int num1,int num2)
	{
		int result=num1-num2;
		System.out.println("Subtraction result:"+result);
	}

}
