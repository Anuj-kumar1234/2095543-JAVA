package HierarchialInheritanceExample;

class Multipication extends Addition {
	public  void Multi(int num1,int num2)
	{
		int result=num1*num2;
		System.out.println("Multipication Result:"+result);
	}

}
