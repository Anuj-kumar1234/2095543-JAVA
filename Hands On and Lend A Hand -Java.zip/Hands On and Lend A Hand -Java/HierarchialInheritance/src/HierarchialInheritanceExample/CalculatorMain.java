package HierarchialInheritanceExample;

public class CalculatorMain {

	public static void main(String[] args) {
		Multipication obj=new Multipication();
		Subtraction.Subtract(9, 7);
		obj.Multi(2,3);
		obj.add(9,7);

	}

}
