package Example;

public class NumberCheck {
	public void displayBigNumber(int num1,int num2,int num3)
	{
		if(num1>num2 && num1>num3)
		{
		   System.out.println("Biggest Number = " +num1);
	    }
		else if(num2>num1 && num2>num3)
		{
			System.out.println("Biggest Number = " +num2);
		}
		else
		{
			System.out.println("Biggest Number = " +num3);
		}
	}

}
