package Example;

public class MainProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NumberCheck nc=new NumberCheck();
		nc.displayBigNumber(22, 8, 23);

	}

}
