package ExampleOverloadingConstructor;

public class StudentMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		studentRecord sr;
		sr=new studentRecord();
		new studentRecord("Anuj kumar",2095543);
		new studentRecord("Anuj kumar",2095543,737);
		
		
				

	}

}
