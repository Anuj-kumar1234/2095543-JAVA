package ExampleOverloadingConstructor;

public class studentRecord {
	studentRecord()
	{
		System.out.println("No Parameters");
	}
	studentRecord(String Name,int rollNo)
	{
		this();
		System.out.println("Student Name =  "+ Name +" "+ "Student Roll Number= "+rollNo);
	}
	studentRecord(String Name,int rollNo,long phoneNo)
	{
		this("anuj Kumar",123);
		System.out.println("Student Name =  "+ Name +" "+ "Student Roll Number= "+rollNo+" "+"Student Contact Number ="+phoneNo);

	}

}
