package AbstractExample;

public class Square extends Shape {
	public double calculateArea()
	{
		double length = 12,breadth=4;
		return (double)length/breadth;
		
	}

}
