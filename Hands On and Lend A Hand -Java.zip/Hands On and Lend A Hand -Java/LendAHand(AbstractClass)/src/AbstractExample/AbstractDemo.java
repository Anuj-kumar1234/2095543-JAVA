package AbstractExample;

public class AbstractDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle cr=new Circle();
		Square sq=new Square();
		System.out.println(cr.calculateArea());
		System.out.println(sq.calculateArea());
		

	}

}
