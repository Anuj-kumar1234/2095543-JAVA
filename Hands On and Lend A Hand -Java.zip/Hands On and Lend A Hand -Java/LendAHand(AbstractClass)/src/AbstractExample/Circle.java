package AbstractExample;

public class Circle extends  Shape{
	public double calculateArea()
	{
		int r=5;
		return 3.14*r*r;
	}
    
}
