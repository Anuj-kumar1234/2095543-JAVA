package com.cognizant.shapes;

public class AreaCalculator {

	public static void main(String[] args) {
		Rectangle rec=new Rectangle();
		rec.calculateArea();

	}

}
