package OverloadDemo;

public class OverloadMain {

	public static void main(String[] args) {
		OverloadingExample oe=new OverloadingExample();
		oe.test();
		oe.test(1);
		oe.test(1,2);
		double result=oe.test(123.2);
		System.out.println("result="+result);

	}

}
