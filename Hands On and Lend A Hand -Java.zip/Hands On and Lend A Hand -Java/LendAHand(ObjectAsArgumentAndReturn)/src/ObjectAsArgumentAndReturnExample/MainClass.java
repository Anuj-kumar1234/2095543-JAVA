package ObjectAsArgumentAndReturnExample;

public class MainClass {
	public static void main(String[] args)
	{
		StudentDetails student=new StudentDetails();
		student.setStudentRollNo(21);
		student.setMark1(39);
		student.setMark2(45);
		student.setMark3(56);
		
		ResultCalculator rc=new ResultCalculator();
		Result result=rc.calculatResult(student);
		System.out.println("student roll no"+result.getRollNo()+"student grade"+result.getGrade());
	}
	

}
