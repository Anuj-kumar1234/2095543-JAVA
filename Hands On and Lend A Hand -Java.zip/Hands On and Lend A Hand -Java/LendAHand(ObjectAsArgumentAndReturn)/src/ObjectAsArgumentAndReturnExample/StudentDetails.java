package ObjectAsArgumentAndReturnExample;

public class StudentDetails {
	private String studentName;
	private int studentRollNo;
	private int mark1;
	private int mark2;
	private int mark3;
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public int getStudentRollNo()
	{
		return studentRollNo;
	}
	public void setStudentRollNo(int studentRollNo)
	{
		this.studentRollNo=studentRollNo;
	}
	public int getMark1() {
		return mark1;
	}
	public void setMark1(int mark1) {
		this.mark1 = mark1;
	}
	public int getMark2() {
		return mark2;
	}
	public void setMark2(int mark2) {
		this.mark2 = mark2;
	}
	public int getMark3() {
		return mark3;
	}
	public void setMark3(int mark3) {
		this.mark3 = mark3;
	}
	

}
