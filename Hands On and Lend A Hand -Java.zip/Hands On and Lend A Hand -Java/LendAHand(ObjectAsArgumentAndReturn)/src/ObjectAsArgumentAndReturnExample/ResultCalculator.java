package ObjectAsArgumentAndReturnExample;

public class ResultCalculator {
	public  Result calculatResult(StudentDetails student)
	{
		int total=student.getMark1()+student.getMark2()+student.getMark3();
		int average=total/3;
		Result result=new Result();
		result.setRollNo(student.getStudentRollNo());
		if(average>40)
		{
			result.setGrade("pass");
		}
		else
		{
			result.setGrade("Fail");
		}
		return result;
	}

}
