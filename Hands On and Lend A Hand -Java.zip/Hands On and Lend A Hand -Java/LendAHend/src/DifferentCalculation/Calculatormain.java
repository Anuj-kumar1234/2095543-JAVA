package DifferentCalculation;
import java.util.*;

public class Calculatormain {

	public static void main(String[] args) {
    Scanner sc=new Scanner(System.in);
    Calculator cal=new Calculator();
    System.out.println("Enter num1 :-");
    cal.num1=sc.nextInt();
    System.out.println("Enter num2 :-");
    cal.num2=sc.nextInt();
    cal.addition(cal.num1, cal.num2);
    cal.division(cal.num1, cal.num2);
    cal.multipication(cal.num1, cal.num2);
    cal.subtraction(cal.num1, cal.num2);

	}

}
