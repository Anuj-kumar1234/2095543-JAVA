package DifferentCalculation;

public class Calculator {
	int num1;
	int num2;
	int result;
	void addition(int num1,int num2)
	{
		 result=num1+num2;
		System.out.println("Resullt :"+result);
		
	}
	void subtraction(int num1,int num2)
	{
		result=num1-num2;
		System.out.println("Resullt :"+result);
	}
	void division(int num1,int num2)
	{
		result=num1/num2;
		System.out.println("Resullt :"+result);
	}
	void multipication(int num1,int num2)
	{
		result=num1*num2;
		System.out.println("Resullt :"+result);
	}

}
