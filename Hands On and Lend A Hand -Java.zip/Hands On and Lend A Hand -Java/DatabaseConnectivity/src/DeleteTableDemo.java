import java.util.Scanner;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
public class DeleteTableDemo {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter empolyee id:-");
		int empolyeeid=sc.nextInt();
		Connection connection=null;
		PreparedStatement pStatement=null;
		try
		{
			Driver driver=new com.mysql.cj.jdbc.Driver();
			DriverManager.registerDriver(driver);
			connection =DriverManager.getConnection("jdbc:mysql://localhost:3306/sqltraning", "root", "root");
			pStatement=connection.prepareStatement("delete from employee where empolyeeid=?");
			pStatement.setInt(1,empolyeeid);
			int a=pStatement.executeUpdate();
			if(a>0){
				System.out.println("records are deleted Sucessfully");
			}
			else
			{
				System.out.println("records are not inserted Sucessfully");
			}
			
				
		}
		catch(Exception e)
		{
			System.out.println("Error:-");
		}
		finally
		{
			pStatement.close();
			connection.close();
		}
		
		
		
		
		
		
		

	}

}
