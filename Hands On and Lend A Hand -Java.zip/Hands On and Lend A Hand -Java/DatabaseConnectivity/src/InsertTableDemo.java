import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;


public class InsertTableDemo {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter employee id:-");
		int employeeid=sc.nextInt();
		System.out.println("Enter employee name:-");
		String employeeName=sc.next();
		System.out.println("Enter employee salary:-");
		int employeeSalary=sc.nextInt();
		Connection connection=null;
		PreparedStatement pStatement=null;
		try
		{
			Driver driver=new com.mysql.cj.jdbc.Driver();
			DriverManager.registerDriver(driver);
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/sqltraning", "root", "root");
			String qry="insert into employee values(?,?,?)";
			pStatement=connection.prepareStatement(qry);
			pStatement.setInt(1,employeeid);
			pStatement.setString(2, employeeName);
			pStatement.setInt(3,employeeSalary);
			
				int a=pStatement.executeUpdate();
				if(a>0)
				{
					System.out.println(a+"Records are Inserted");
				}
				else
				{
					System.out.println("Records are not Inserted");
				}
		}
		catch(Exception e)
		{
			System.out.println("Error:-"+e);
		}
		finally
		{
			pStatement.close();
			connection.close();
		}
		sc.close();
		
			
		
		
		
		
		
		

	}

}
