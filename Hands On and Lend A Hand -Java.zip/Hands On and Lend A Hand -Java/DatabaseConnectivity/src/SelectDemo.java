import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;

public class SelectDemo {
	
	public static void main(String[] args) throws SQLException {
		Statement statement=null;
		Connection connection =null;
		
		try{
			Driver driver=new com.mysql.cj.jdbc.Driver();
		      DriverManager.registerDriver(driver);
		      
		      //Connect to database
		    connection =DriverManager.getConnection("jdbc:mysql://localhost:3306/sqltraning", "root","root");
			String query="Select * from employee";
			statement=connection.createStatement();
			ResultSet rset=statement.executeQuery(query);
			while(rset.next())
			{
				System.out.println(rset.getInt(1)+" "+rset.getString(2) +" "+ rset.getInt(3));
			}
			
		}
		catch(Exception e)
		{
			System.out.println("Error :-");
		}
		finally
		{
			statement.close();
			connection.close();
		}
		
		

	}	

}
