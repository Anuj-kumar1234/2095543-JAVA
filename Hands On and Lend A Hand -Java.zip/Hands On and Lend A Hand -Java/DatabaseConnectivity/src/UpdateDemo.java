import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;


public class UpdateDemo {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter employee id:-");
		int empolyeeid=sc.nextInt();
		System.out.println("Enter employee name:-");
		String employeeName=sc.next();
		
		Connection connection=null;
		PreparedStatement pStatement=null;
		try
		{
			Driver driver=new com.mysql.cj.jdbc.Driver();
			DriverManager.registerDriver(driver);
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/sqltraning", "root", "root");
			
			pStatement=connection.prepareStatement("Update  employee set employeeName=? where empolyeeid=?");
			pStatement.setString(1, employeeName);
			pStatement.setInt(2, empolyeeid);
			
			
				int a=pStatement.executeUpdate();
				if(a>0)
				{
					System.out.println(a+"Records are Updated");
				}
				else
				{
					System.out.println("Records are not Updated");
				}
		}
		catch(Exception e)
		{
			System.out.println("Error:-"+e);
		}
		finally
		{
			pStatement.close();
			connection.close();
		}
		sc.close();
		
			
		
		
		
		
		
		

	}

}

