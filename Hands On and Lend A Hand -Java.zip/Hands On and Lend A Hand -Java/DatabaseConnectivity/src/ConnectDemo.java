import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
public class ConnectDemo {

	public static void connectHelp() throws SQLException {
		// TODO Auto-generated method stub
		//Load a Driver
      Driver driver=new com.mysql.cj.jdbc.Driver();
      DriverManager.registerDriver(driver);
      
      //Connect to database
      Connection connection =DriverManager.getConnection("jdbc:mysql://localhost:3306/sqltraning", "root","root");
      
      
        
	}

}
