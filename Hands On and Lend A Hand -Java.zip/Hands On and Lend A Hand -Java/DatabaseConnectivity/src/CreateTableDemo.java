import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
public class CreateTableDemo {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		Driver driver=new com.mysql.cj.jdbc.Driver();
		DriverManager.registerDriver(driver);
		Connection connection =DriverManager.getConnection("jdbc:mysql://localhost:3306/sqltraning","root","root");
		try
		{
			String query="create table employee(empolyeeid int primary key,employeename varchar(20),employeeSalary Varchar(30)) ";
		     Statement statement =connection.createStatement();
		     statement.execute(query);
		}
		catch(Exception e)
		{
			System.out.println("Error :-"+e);
		}
		
		

	}

}
