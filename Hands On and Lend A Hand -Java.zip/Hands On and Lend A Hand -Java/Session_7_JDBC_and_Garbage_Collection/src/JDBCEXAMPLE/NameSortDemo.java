package JDBCEXAMPLE;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
import java.util.Scanner;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
public class NameSortDemo {
	 
	 static int Student_Id;
	 static String First_name;
	 static  Connection connection ;
	 

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		/*Scanner sc=new Scanner(System.in);
		System.out.println("Enter Student Id:-");
		 Student_Id=sc.nextInt();
		 System.out.println("Enter First_Name");
		 First_name=sc.next();*/
		connection=NameSortDemo.connectDataBase();
		/*if(NameSortDemo.insertStudent()>0)
		{
			System.out.println("Records are inserted ");
		}
		else
		{
			System.out.println("error in inserting record");
		}*/
		NameSortDemo.sortStudents();
		//sc.close();
		connection.close();
		
		
		

	}
	public static Connection connectDataBase()//for connection to data base
	
	{
		
		try
		{
			 Driver driver=new com.mysql.cj.jdbc.Driver();
			 DriverManager.registerDriver(driver);
			 connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/sqltraning", "root", "root");
			 return connection;
		}
		catch(Exception e)
		{
			System.out.println("Error "+e);
		}
		
		return connection;
		
		
	}
	public static void createStudent()
	{
		try
		{
			Statement statement=connection.createStatement();
			String query="Create table Student(Student_Id int  primary key,First_name varchar(20))";
			statement.execute(query);
		}
		catch(Exception e)
		{
			System.out.println("Error"+e);
		}
	}
	public static int  insertStudent()
	{
		int recordInserted=0;
		try
		{
			String query="Insert into Student  values(?,?)";
			PreparedStatement ps=connection.prepareStatement(query);
			ps.setInt(1,Student_Id);
			ps.setString(2, First_name);
			recordInserted=ps.executeUpdate();
		}
		catch(Exception e)
		{
			System.out.println("Error"+e);
		}
		return recordInserted;
		
	}
	public static void sortStudents()
	{
		Statement statement=null;
		ResultSet rs=null;
		try
		{
			 statement=connection.createStatement();
			String query="Select * from Student";
			 rs=statement.executeQuery(query);
			while(rs.next())
			{
				System.out.println(rs.getInt("Student_Id")+" "+ rs.getString("First_name"));
			}
			
		}
		catch(Exception e)
		{
			System.out.println("Error"+e);
		}
		
		
	}
	

}
