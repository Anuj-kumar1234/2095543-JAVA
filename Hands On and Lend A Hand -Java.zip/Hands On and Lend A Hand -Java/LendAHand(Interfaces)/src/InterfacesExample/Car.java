package InterfacesExample;

public class Car extends MotorisedVehicle implements IVehicle {
	public void drive()
	{
		System.out.println("The car is in drive mode");
	}
	public void turnLeft()
	{
		System.out.println("Take car to the left direction ");
	}
    public void brake()
    {
    	System.out.println("Apply Brake");
    }
}
