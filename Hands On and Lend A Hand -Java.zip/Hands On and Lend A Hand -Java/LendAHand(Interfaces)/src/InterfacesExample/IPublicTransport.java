package InterfacesExample;

public interface IPublicTransport {
	public void getNumberPeople();

}
