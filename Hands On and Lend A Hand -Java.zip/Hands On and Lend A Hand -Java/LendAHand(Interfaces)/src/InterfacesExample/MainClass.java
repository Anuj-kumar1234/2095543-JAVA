package InterfacesExample;

public class MainClass {

	public static void main(String[] args) {
		Car car=new Car();
		Train train=new Train();
		System.out.println("Fuction of car");
		car.drive();
		car.turnLeft();
		car.brake();
		System.out.println("Function of Train");
		train.drive();
		train.turnLeft();
		train.brake();

	}

}
