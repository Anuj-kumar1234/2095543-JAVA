package InterfacesExample;

public class Train implements IVehicle, IPublicTransport {

	@Override
	public void getNumberPeople() {
		// TODO Auto-generated method stub
		System.out.println("Number of people in train");
		
	}

	@Override
	public void drive() {
		// TODO Auto-generated method stub
		System.out.println("Train is driving at a speed of 70km/hr");
	}

	@Override
	public void turnLeft() {
		// TODO Auto-generated method stub
		
		System.out.println("The train is turning Left");
	}

	@Override
	public void brake() {
		// TODO Auto-generated method stub
		System.out.println("Train applys Brake");
	}

}
