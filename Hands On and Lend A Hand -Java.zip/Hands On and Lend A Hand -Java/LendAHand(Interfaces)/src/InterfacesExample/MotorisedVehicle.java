package InterfacesExample;

public class MotorisedVehicle {
	public static void checkMotor()
	{
		System.out.println("The Motor of the Vehicle is in Good Condition");
	}

}
