package Class;

public class Student {
	public int registrationId;
	public void displayRegistrartionId()
	{
		System.out.println("Student Registrartion Id="+registrationId);
	}

}
