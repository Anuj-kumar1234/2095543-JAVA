package Class;

public class StudentMain {

	public static void main(String[] args) {
		Student st=new Student();
		st.registrationId=1290;
		st.displayRegistrartionId();

	}

}
